package pacote;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MessengerController {

	@Autowired
	private UsuarioRepository ur;

	@Autowired
	private MensagemRepository mr;

	@PostMapping("/cadastrar")
	@ResponseBody
	public String cadastrar(@RequestParam(required = true) String nome, @RequestParam(required = true) int senha) {

		Usuario usuario = new Usuario();

		List<Usuario> nomesCadastrados = new ArrayList<>();

		nomesCadastrados = ur.getAllByNome(nome);

		if (nomesCadastrados.size() == 0) {
			usuario.setNome(nome);
			usuario.setSenha(senha);

			ur.save(usuario);
			return "saved";
		} else {
			return "nome já cadastrado!";
		}

	}

	/*
	 * @PostMapping("/usuarios")
	 * 
	 * @ResponseBody public List<Usuario> listarUsuarios() {
	 * 
	 * List<Usuario> listaUsuarios = ur.findAll(); return listaUsuarios; }
	 */
	@GetMapping("/usuarios")
	@ResponseBody
	public String listarTodos() {
		return toHtml(ur.findAll());
	}

	private String toHtml(List<Usuario> lista) {
		StringBuilder html = new StringBuilder();
		for (Usuario u : lista) {
			html.append("<p>");
			html.append(u.getNome()).append("<br />");
			html.append(u.getSenha()).append("<br />");
			html.append("<p>");
		}
		return html.toString();

	}

	@PostMapping("/enviar")
	@ResponseBody
	public String enviarMensagem(@RequestParam(required = true) String remetente,
			@RequestParam(required = true) int senha, @RequestParam(required = true) String destinatario,
			@RequestParam(required = true) String texto) {

		// Usuario usuario = new Usuario();
		Mensagem mensagem = new Mensagem();

		List<Usuario> remetenteCadastrado = new ArrayList<>();
		List<Usuario> destinarioCadastrado = new ArrayList<>();

		remetenteCadastrado = ur.getAllByNomeAndSenha(remetente, senha);
		destinarioCadastrado = ur.getAllByNome(destinatario);

		if (remetenteCadastrado.size() == 0) {

			return "Não existe remetentes com esse nome!";
		} else {
			if (destinarioCadastrado.size() == 0) {
				return "Não existe destinarios com esse nome!";

			} else {
				Date dataAtual = new Date(System.currentTimeMillis());
				mensagem.setDestinatario(destinatario);
				mensagem.setRemetente(ur.getOne(remetente));
				mensagem.setTexto(texto);
				mensagem.setDataEnvio(dataAtual);
				mr.save(mensagem);
				return "Mensagem enviada!";
			}

		}

	}

	/*@PostMapping("/mensagens")
	public String listarMensagens(@RequestParam(required = true) String buscador) {

		List<Mensagem> listarTodas = mr.findAllById(buscador);
		
		
		
		return null;
	}*/
}
