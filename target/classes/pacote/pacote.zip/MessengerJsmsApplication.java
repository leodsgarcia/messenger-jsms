package pacote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessengerJsmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessengerJsmsApplication.class, args);
	}

}
