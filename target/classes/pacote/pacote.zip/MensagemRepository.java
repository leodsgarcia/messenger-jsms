package pacote;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MensagemRepository  extends JpaRepository <Mensagem, Integer>{

	
	List<Mensagem> findAllById(String busca);
}

